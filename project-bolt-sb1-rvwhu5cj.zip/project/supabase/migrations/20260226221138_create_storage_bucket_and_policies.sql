/*
  # Create Supabase Storage bucket for site images

  1. Creates storage bucket 'site-images' with public access
  2. Sets up RLS policies for the storage.objects table
     - Public read for site-images bucket
     - Anon users can upload to site-images (admin uploads via frontend)
*/

-- Create the bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'site-images',
  'site-images',
  true,
  10485760,
  ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp']
)
ON CONFLICT (id) DO NOTHING;

-- Allow public read of objects in site-images bucket
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Public read site-images'
  ) THEN
    CREATE POLICY "Public read site-images"
      ON storage.objects FOR SELECT
      TO public
      USING (bucket_id = 'site-images');
  END IF;
END $$;

-- Allow anon to upload to site-images (admin panel uses anon key with credential check)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Admin upload site-images'
  ) THEN
    CREATE POLICY "Admin upload site-images"
      ON storage.objects FOR INSERT
      TO anon
      WITH CHECK (bucket_id = 'site-images');
  END IF;
END $$;

-- Allow anon to update objects in site-images
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'storage' 
    AND tablename = 'objects' 
    AND policyname = 'Admin update site-images'
  ) THEN
    CREATE POLICY "Admin update site-images"
      ON storage.objects FOR UPDATE
      TO anon
      USING (bucket_id = 'site-images');
  END IF;
END $$;
